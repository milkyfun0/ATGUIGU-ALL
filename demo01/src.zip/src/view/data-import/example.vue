<template>
  <!--  <el-text class="mx-1">条件 {{": "}}</el-text>-->
  <span>
<!--     <el-select-->
    <!--         v-model="value"-->
    <!--         placeholder="筛选"-->
    <!--         style="width: 100px"-->
    <!--     >-->
    <!--      <el-option-->
    <!--          v-for="[item, temp] in props"-->
    <!--          :key="item"-->
    <!--          :label="item"-->
    <!--          :value="item"-->
    <!--      />-->
    <!--    </el-select>-->

    <!--    <el-text>{{value}}</el-text>-->

    <el-tag v-for="tag in dynamicTags"
            :key="tag"
            :size="'large'"
            :hit="true"
            closable
            :disable-transitions="false"
            @close="handleClose(tag)"
            style="margin-left: 10px"
    >
      {{ tag }}
    </el-tag>
  </span>

  <el-table :data="tableData" style="width: 100%" max-height="500"
            @header-click="headClick" border stripe>
    <el-table-column v-for="[p,f] in props" :prop="p" :label="p" :fixed="f" :width="150" align="center">
      <template #header>
        <newnew v-if="click_value==p" :column="p"></newnew>
        <!--        <el-text>{{ scope }}</el-text>-->
      </template>
    </el-table-column>
    <el-table-column label="Info" :fixed="'right'">
      <template #default="scope">
        <el-button type="primary" size="small" @click="more_about()"
        >ShowMore
        </el-button
        >
      </template>
    </el-table-column>
  </el-table>
</template>

<script lang="ts" setup>
import {zip} from '@/api/utils'
import {nextTick, ref} from 'vue'
import {ElMessage, ElMessageBox, ElInput} from 'element-plus'
import type {Action} from 'element-plus'
import {getTableData, getTableProps} from "@/api/test-data"
import customHeader from "@/view/data-import/customHeader.vue";
import newnew from "./newnew.vue"

let click_value = ref("")

function log() {
  console.log("stop")
}

const row_labels = getTableProps()
const tableData = getTableData()
const fixed = Array(row_labels.length)
fixed[0] = true
for (let i = 1; i < row_labels.length; i++) {
  fixed[i] = false
}
const props = zip(row_labels, fixed)


const inputValue = ref('')
const dynamicTags = ref(['Tag 1', 'Tag 2', 'Tag 3'])
const inputVisible = ref(false)
const InputRef = ref<InstanceType<typeof ElInput>>()

const handleClose = (tag) => {
  dynamicTags.value.splice(dynamicTags.value.indexOf(tag), 1)
  console.log(`delete tag: ${tag}`)
}

function headClick(column, event) {
  // console.log(`${column.label} - ${event}`)
  click_value.value = column.label
}

function more_about() {
  ElMessageBox.alert('this is more information', 'Info', {
    // if you want to disable its autofocus
    // autofocus: false,
    confirmButtonText: 'OK',
    callback: (action: Action) => {
      // ElMessage({
      //   type: 'info',
      //   message: `action: ${action}`,
      // })
    },
  })
}

</script>

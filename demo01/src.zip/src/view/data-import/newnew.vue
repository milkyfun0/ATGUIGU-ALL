<template>
  <div @click.stop style="display: inline-block ">
    <el-popover
        placement="bottom"
        title="查询条件"
        trigger="hover"
        :visible=open_flag
        ref="popoverRef"
    >
      <template #reference>
        <!--        <el-button>-->
        <!--          <el-text tag="b" type="primary">{{ column }}</el-text>-->
        <!--        </el-button>-->
        <span @click="open_flag=true">{{ column }}</span>

      </template>
      <div style="text-align: right; margin: 0">
        <el-button size="small" text @click="open_flag=false">cancel</el-button>
        <el-button size="small" type="primary" @click="open_flag=false">confirm
        </el-button
        >
      </div>

    </el-popover>
  </div>
</template>
<script>
import {ref} from "vue";

export default {
  name: "newnew",
  props: ["column", "column_type"],
  data() {
    return {
      open_flag: ref(true)
    }
  },
  methods: {
    destroy() {

    },
    confirm() {
      this.destroy()
    },
    cancel() {

    }
  }
}
</script>

function getRandomInt(Max, Min) {
    let Range = Max - Min;
    let Rand = Math.random();
    return (Min + Math.round(Rand * Range));
}

function getRandomArray(length, Max, Min) {
    let array = Array(length)
    for (let i = 0; i < length; i++) {
        array[i] = getRandomInt(Max, Min)
    }
    return array.sort(function (a, b) {
        return a - b
    })
}

function zip<T, U>(arr1: T[], arr2: U[]): [T, U][] {
    return arr1.map((value, index) => [value, arr2[index]]);
}

export {getRandomArray, zip}